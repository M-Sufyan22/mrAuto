import React, { useEffect, useState, forwardRef } from "react";
import firebase from "../config/firebase";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import "../assets/css/addCart.css";
import Button from "@material-ui/core/Button";
import FormModel from "../components/loginForm/FormModel";
import { FaMinusCircle, FaPlusCircle, FaTimes, FaTimesCircle, FaTrashAlt } from "react-icons/fa";
import { BiBasket } from "react-icons/bi";
import { Link } from "react-router-dom";
import { get_All_Products, check_current_user, set_user_cart } from "../store/action/action";
import Loader from "../components/Others/Loader";
import DeleteIcon from "@material-ui/icons/Delete";
import DoneAllIcon from "@material-ui/icons/DoneAll";
import EditRounded from "@material-ui/icons/EditRounded";
import PageviewIcon from "@material-ui/icons/Pageview";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Slide from "@material-ui/core/Slide";


const MyCart = (props) => {
  const [cartItems, setCartItems] = useState([]);
  const [qtn, setQtn] = useState([]);
  const [showLoader, setShowLoader] = useState(true);
  const [open, setOpen] = useState(false);
  const [myAlert, setMyAlert] = useState({
    msg: ""
  });


  useEffect(() => {
    setShowLoader(true)
    getCartitems();
  }, [props.currentuser]);

  var user = props.currentuser;
  var dbProdRef = firebase.database().ref("all_Products/categories/");
  var db = firebase.database();

  let price = [];
  let prd = [];
  let cat = [];
  let id = [];

  function getCartitems() {
    prd = [];
    let isAvailable = Object.keys(user).length;
    if (isAvailable !== 0) {
      db.ref(`users/${user.userUid}/cartItems`).once('value').then((data) => {
        if (data) {
          prd = data.val();
          setStateForProducts();
          setShowLoader(false);
        }
      }).catch((error) => {

        setOpen(true); setMyAlert({ msg: error.message })
      })
    } else {
      setTimeout(() => {
        setShowLoader(false);
      }, 3000)

    }
  }


  function setStateForProducts() {
    let prddd = [];
    cat = [];
    id = [];
    let q = []
    setQtn([])
    if (prd) {
      Object.values(prd).map((v, i) => {
        cat.push(v.cate)
        id.push(v.productID);
        q.push(v.qtn);
        setQtn(q);
        
      })
      if (cat.length > 0) {
        cat.map((ct, i) => {
          dbProdRef
            .child(ct).child(id[i])
            .get().then((prod) => {
              if (prod.exists()) {
                prddd.push(prod.val())
                if (i === cat.length - 1) {
                  setCartItems(prddd);
                  props.set_user_cart();
                }
              }
            })
            .catch((error) => {

              setOpen(true); setMyAlert({ msg: error.message })
            });
        })
      }
    }
  }

  const upDateCartQtn = (method, productCate, productid, del) => {

    let isAvailable = Object.keys(user).length;

    if (isAvailable !== 0) {
      let ProdRef = db.ref('users').child(user.userUid).child('cartItems').child(productid);
      if (method) {
        ProdRef.get().then((itm) => {
          if (itm.exists()) {
            switch (method) {
              case '+':
                ProdRef.set({
                  productID: itm.val().productID,
                  cate: itm.val().cate,
                  qtn: itm.val().qtn >= 5 ? 5 : itm.val().qtn + 1,
                });
                if (itm.val().qtn >= 5) { setOpen(true); setMyAlert({ msg: "Maximum Quantity of single product is 5" }) }
                break;
              case "-":

                ProdRef.set({
                  productID: itm.val().productID,
                  cate: itm.val().cate,
                  qtn: itm.val().qtn < 2 ? 1 : itm.val().qtn - 1,
                });
                if (itm.val().qtn < 2) { setOpen(true); setMyAlert({ msg: "Minimum Quantity of single product is 1" }) }
            }

            props.check_current_user()

          } else {


            setOpen(true); setMyAlert({ msg: "NO Records are found of this product in our Database!" })
          }
        });
      }
      if (del) {

        ProdRef.remove().then((itm) => {
          setOpen(true);
          setMyAlert({ msg: "Removed From Cart Successfully!" })
        })
      }


    }

  }
  const clearCart = () => {
    setOpen(true);
    setMyAlert({ msg: "Are you Sure you want to Clear your cart ?", delAll: "Yes" });

  }
  const  clearedCart = () => {
    db.ref(`users/${props.currentuser.userUid}`).child("cartItems").remove().then(()=>{
      setOpen(true);
      setMyAlert({ msg: "Your cart has been Cleared Successfully!",});
      props.check_current_user();
    })
  }
  const openAlertBox = () => {
    open ? setOpen(false) : setOpen(true);
  };

  return (
    <>

      <div className="container_section">
        {Object.keys(props.currentuser).length !== 0 ? (
          props.currentuser.cartItems ?
            <div>
              <div className="deletAll">
                <Button style={{ backgroundColor: "#ff5e14", color: "#fff" }}
                  onClick={clearCart}
                  variant="contained">
                  Clear Cart
                 &nbsp; <FaTrashAlt />
                </Button>
              </div>

              <div className="cart_header">
                <h2>Product</h2>
                <h4>Price</h4>
                <h4>Quantity</h4>
                <h4>Sub Total</h4>
              </div>

              <div className="cart_container">

          
                {Object.values(cartItems).map((item, key) => {

                  return (
                    <>

                      <div className="cart_details" key={key}>
                        <div className="cart_img">
                          <FaTimesCircle className="remove" onClick={() => upDateCartQtn(' ', item.prod.category, item.prod.key, 'del')} />
                          <img src={item.prod.imgs[0]} alt="" />
                          <span className="cart_name">{item.prod.title}</span>
                        </div>
                        <div className="cart_price">{item.prod.price}</div>
                        <div className="cart_qtn">
                          <FaMinusCircle
                            className="inc_dec dec_cart"
                            onClick={() => upDateCartQtn("-", item.prod.category, item.prod.key)}
                          />
                          <span className="qtn_box">{qtn[key]}</span>
                          <FaPlusCircle
                            className="inc_dec inc_cart"

                            onClick={() => upDateCartQtn('+', item.prod.category, item.prod.key)}
                          />
                        </div>
                        <div className="cart_item_total">
                          <span id="total_pr">
                            RS: {parseInt(item.prod.price * qtn[key])

                            }
                            <span style={{ display: "none" }}>
                              {
                                price.push(parseInt(item.prod.price * qtn[key]))
                              }
                            </span>



                          </span>
                        </div>
                      </div>
                    </>
                  );
                })}
              </div>

              <div className="total_cartPrice">
                <div className="final_ptice">
                  <h2>Cart Totals</h2>
                  <div className="final_p_box">
                    <span>Total Cart Items</span>
                    <span id="total_cartitems">Qtn : {
                      qtn.reduce((a, b) => a + b, 0) < 10 ? "0" + qtn.reduce((a, b) => a + b, 0) : qtn.reduce((a, b) => a + b, 0)}
                    </span>
                    <span>Total Cart Price</span>
                    <span id="total_cartPrice">Rs :  &nbsp;
                  {
                        price.length > 0 ?
                          price.reduce((a, b) => a + b, 0)


                          : " 00"

                      }
                    </span>
                    <span>Shipping Fee</span>
                    <span id="ship_fees">RS : 50.00</span>
                    <span>Final Order Price</span>
                    <span id="final_price">RS : &nbsp; {
                      price.length > 0 ?
                        price.reduce((a, b) => a + b, 0) + 50


                        : " 00"

                    }</span>
                  </div>
                  <Button className="mybtn" contained  component={Link} to="/Checkout">Proceed to Checkout</Button>
                </div>
              </div>

            </div>

            :
            <div style={{ textAlign: "center", margin: "50px auto" }}>
              <BiBasket style={{ fontSize: "7vh", color: "orange" }} />
              <h1 style={{ color: "orange" }}>No Items in your cart </h1>
              <Button component={Link} onClick={() => props.history.push('/Shop')} variant="contained" style={{ backgroundColor: "#ff5e14", color: "#fff" }}>Shop Now</Button>
            </div>

        ) : (
          <>
            <div className="container">
              <div className="row">
                {showLoader ?
                  <Loader />



                  :


                  <div className="col-12 d-flex flex-column justify-content-center align-items-center text-center" style={{ height: "60vh" }}>
                    <FormModel name="Login" />
                    <br />
                    <Button onClick={() => props.history.goBack()}>Go Back</Button>

                  </div>
                }
              </div>
            </div>

          </>
        )}

      </div>
      {open && <ConfirmDialog msg={myAlert.msg} head={"Alert!"} delAll={myAlert.delAll === "Yes" && "Yes"} open={open} close={openAlertBox} confirmedDelete={clearedCart}/>}
    </>
  );
};

const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const ConfirmDialog = (props) => {


  return (
    <>

      <Dialog
        open={props.open}
        TransitionComponent={Transition}
        keepMounted
        onClose={props.close}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">{props.head}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            {props.msg}
          </DialogContentText>
        </DialogContent>
        <DialogActions>


          {props.delAll ?
          <>
            <Button
              style={{backgroundColor: "#ff5e14", color: "#fff" }}
              onClick={props.close}
              variant="contained"
            >
              No
              <FaTimes />
            </Button>
            <Button
              color="secondary"
              onClick={()=> props.confirmedDelete()}
              variant="contained"
            >
              {props.delAll}
              <DeleteIcon />
            </Button>
            </>
            :
            <Button
              color="primary"
              onClick={props.close}
              variant="contained"
            >
              ok
           <DoneAllIcon />
            </Button>
          }

        </DialogActions>
      </Dialog>
    </>
  );
};



const mapStateToProps = (store) => ({
  currentuser: store.currentuser,
});
const mapDispatchToProps = (dispatch) => ({
  get_All_Products: () => dispatch(get_All_Products()),
  check_current_user: () => dispatch(check_current_user()),
  set_user_cart: () => dispatch(set_user_cart()),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(MyCart));
