import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Paper from "@material-ui/core/Paper";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import Button from "@material-ui/core/Button";
import Link from "@material-ui/core/Link";
import Typography from "@material-ui/core/Typography";
import AddressForm from "../components/checkoutFrom/AddressForm";
import PaymentForm from "../components/checkoutFrom/PaymentForm";
import Review from "../components/checkoutFrom/Review";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { get_All_Products, check_current_user, set_user_cart } from "../store/action/action";
import "../assets/css/checkOut.css";
import Loader from "../components/Others/Loader";
import FormModel from "../components/loginForm/FormModel";
import { BiBasket } from "react-icons/bi";

const useStyles = makeStyles((theme) => ({
  appBar: {
    position: "relative",
  },
  layout: {
    width: "auto",
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
    [theme.breakpoints.up(600 + theme.spacing(2) * 2)]: {
      width: 600,
      marginLeft: "auto",
      marginRight: "auto",
    },
  },
  paper: {
    marginTop: theme.spacing(3),
    marginBottom: theme.spacing(3),
    padding: theme.spacing(2),
    [theme.breakpoints.up(600 + theme.spacing(3) * 2)]: {
      marginTop: theme.spacing(6),
      marginBottom: theme.spacing(6),
      padding: theme.spacing(3),
    },
  },
  stepper: {
    padding: theme.spacing(3, 0, 5),
  },
  buttons: {
    display: "flex",
    justifyContent: "flex-end",
  },
  button: {
    marginTop: theme.spacing(3),
    marginLeft: theme.spacing(1),
  },
}));


function Checkout(props) {
  
  const [showLoader, setShowLoader] = useState(true);
  const classes = useStyles();
  const [activeStep, setActiveStep] = useState(0);
  const [FormDetails, setFormDetails] = useState({
    userName: "",
    phone: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    country: "Pakistan ",
    zip: "",
    NameOnCard: "",
    cardNumber: "",
    ExpiryDate: "",
    CVV: "",
    
  })
  
  useEffect(() => {
    if (Object.keys(props.currentuser).length !== 0) {
        props.set_user_cart();
  
         setFormDetails({
           ...FormDetails,
           userName: props.currentuser.userName,
           phone: props.currentuser.phone,
           address1: props.currentuser.address,
          });
          setShowLoader(false);    
          setActiveStep(0)
    }
    else {
      setShowLoader(true)
      setTimeout(() => {
        setShowLoader(false);
       },3000);
    }

  }, [props.currentuser])

   
  const handleNext = () => {
    setActiveStep(activeStep + 1);
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  const handleFormData = (e) => {
    setFormDetails({ ...FormDetails, [e.target.name]: e.target.value })
  }


  const steps = ["Shipping address", "Payment details", "Review your order"];

  function getStepContent(step) {
    switch (step) {
      case 0:
        return <AddressForm fillForm={handleFormData} formData={FormDetails} />;
      case 1:
        return <PaymentForm fillForm={handleFormData} formData={FormDetails} />;
      case 2:
        return <Review fillForm={handleFormData} cartData={props.userCart} />;
      default:
        throw new Error("Unknown step");
    }
  }


  return (
    <React.Fragment>
      <CssBaseline />
      <main className={classes.layout}>
        {Object.keys(props.currentuser).length !== 0 ? (
          props.currentuser.cartItems ?
            <Paper className={classes.paper}>
              <Typography component="h1" variant="h4" align="center">
                Checkout
          </Typography>
              <Stepper activeStep={activeStep} className={classes.stepper}>
                {steps.map((label) => (
                  <Step key={label}>
                    <StepLabel>{label}</StepLabel>
                  </Step>
                ))}
              </Stepper>
              <React.Fragment>
                {activeStep === steps.length ? (
                  // <React.Fragment>
                  //   <Typography variant="h5" gutterBottom>
                  //     Thank you for your order.
                  //   </Typography>
                  //   <Typography variant="subtitle1">
                  //     Your order number is #2001539. We have emailed your order
                  //     confirmation, and will send you an update when your order has
                  //     shipped.
                  //   </Typography>
                  // </React.Fragment>

                  <>
                    <div className="container_section">
                      <div className="thx_for_shop">
                        <p>Order has been successfully placed!</p>
                        <a className="mybtn" href="index.html">Continue Shopping</a>
                      </div>
                      <div className="cont">
                        <div className="down_inv">
                          <h2>Your Invoice</h2>
                          <button className="mybtn" id="download">Download Invoice <i className="fa fa-download" aria-hidden="true" /></button>
                        </div>
                        <div className="invoice_sec" id="invoice">
                          {/* Reciept Top section */}
                          <div className="inv_top_sec">
                            <div className="logo inv_logo">
                              <h1>E-Shop</h1>
                              <p style={{ color: '#fff', fontSize: '12px' }} href="index.html">www.E-shop.com</p>
                            </div>
                            <div className="inv_data">
                              <h3 id="invoice_number">Order #004356</h3>
                              <div id="p_date">Date: 28 feb 2020</div>
                            </div>
                          </div>
                          <h3 className="cl_i">Client Informations</h3>
                          {/* Reciept Bottom section */}
                          <div className="inv_bottom_sec">
                            <div className="inv_clint_Info">
                              <p>Name: <span id="c_name"> John Doe</span></p>
                              <p>Email: <span id="c_email"> mmuhammadsufyan5@gmail.com</span></p>
                              <p>Address: <span id="c_address"> House 558 old Golimar karachi</span></p>
                              <p>Country: <span id="c_country"> Pakistan</span></p>
                            </div>
                            <div className="inv_payment_sec">
                              <p>Payment Method: <span id="pm_m"> Card</span></p>
                              <p>Phone: <span id="c_phone"> 03492487972</span></p>
                              <p>Postal/Zip Code: <span id="c_zip"> 75700</span></p>
                            </div>
                          </div>
                          {/* Products List */}
                          <h3 className="cl_i">Products details</h3>
                          <div className="inv_head cart_header">
                            <h2>Product</h2>
                            <h4>Price</h4>
                            <h4>Quantity</h4>
                            <h4>Sub Total</h4>
                          </div>
                          <div className="inv_p cart_container" />
                          {/* total Price section */}
                          <div className="total_cartPrice">
                            <div className="final_ptice inv_final_p">
                              <h2>Products Totals</h2>
                              <div className="final_p_box">
                                <span>Total Cart Items</span><span id="total_cartitems">$00.00</span>
                                <span>Total products Price</span><span id="total_cartPrice">$00.00</span>
                                <span>Shipping Fee</span><span id="ship_fees">$00.00</span>
                                <span style={{ backgroundColor: '#000', color: '#fff' }}>Final Order Price</span><span style={{ backgroundColor: '#000', color: '#fff' }} id="final_price">$00.00</span>
                              </div>
                            </div>
                          </div>
                          {/*Last Comment section  */}
                          <br />
                          <p className="wt_m">If you have any questions about this, Please Comntact.</p>
                          <p className="wt_m">@E-shop.com.Help &amp; Support</p> <br />
                          <p className="wt_m">Thankyou! For Shopping</p>
                          <br /><br />
                          {/* Reciept Footer */}
                          <div style={{ justifyContent: 'flex-start', borderBottomRightRadius: '7px', borderBottomLeftRadius: '7px' }} className="inv_head cart_header">
                            <p className="wt_m" style={{ color: '#fff', fontWeight: 300 }}>https://Www.E-shop.com</p>
                          </div>
                        </div>
                      </div></div>
                  </>

                ) : (
               
                    Object.keys(props.currentuser).length !== 0 ? 
                      <React.Fragment>
                      {getStepContent(activeStep)}
                         
                         <div className={classes.buttons}>
                           {activeStep !== 0 && (
                             <Button onClick={handleBack} className={classes.button}>
                               Back
                             </Button>
                           )}
                           <Button
                             variant="contained"
                             color="primary"
                             onClick={handleNext}
                             className={classes.button}
                           >
                             {activeStep === steps.length - 1 ? "Place order" : "Next"}
                           </Button>
                         </div>
                         </React.Fragment>
                    
                            : null
                    
                 
                 
                )}
              </React.Fragment>
            </Paper>
            :
            <div style={{ textAlign: "center", margin: "50px auto" }}>
              <BiBasket style={{ fontSize: "7vh", color: "orange" }} />
              <h1 style={{ color: "orange" }}>No Items in your cart For Checkout Please add some products to your cart first </h1>
              <Button component={Link} onClick={() => props.history.push('/Shop')} variant="contained" style={{ backgroundColor: "#ff5e14", color: "#fff" }}>Shop Now</Button>
            </div>

        ) : (
          <>
            <div className="container">
              <div className="row">
                {showLoader ?
                  <Loader />



                  :


                  <div className="col-12 d-flex flex-column justify-content-center align-items-center text-center" style={{ height: "60vh" }}>
                    <FormModel name="Login" />
                    <br />
                    <Button onClick={() => props.history.goBack()}>Go Back</Button>

                  </div>
                }
              </div>
            </div>

          </>
        )}
      </main>
    </React.Fragment>
  );
}




const mapStateToProps = (store) => ({
  currentuser: store.currentuser,
  userCart: store.userCart,
});
const mapDispatchToProps = (dispatch) => ({
  get_All_Products: () => dispatch(get_All_Products()),
  check_current_user: () => dispatch(check_current_user()),
  set_user_cart: () => dispatch(set_user_cart()),

});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(Checkout));
