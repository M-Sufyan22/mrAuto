import React from "react";
import AppRouter from "../config/routes.jsx";
import "bootstrap/dist/css/bootstrap.min.css";


export default function App() {
  return (
    <div>
      <>
      <AppRouter />
    </>
    </div>
  );
}
