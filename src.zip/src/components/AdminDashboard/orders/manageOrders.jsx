import React from 'react'

const manageOrders = () => {
    return (
        <div>
            <h1>We will Manage our Orders here... soon</h1>
        </div>
    )
}

export default manageOrders
